from django.contrib import admin
from carrier.models import Item
# Register your models here.
admin.site.register(Item)