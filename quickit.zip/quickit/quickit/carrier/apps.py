from django.apps import AppConfig


class CarrierConfig(AppConfig):
    name = 'carrier'
    