# QuickIT
This is Software development project 2 web based application

Project will be done with django framework.
#Project members:
#shalik sapkota
#Rachit khanal
#Kamal lamsal
#Rakesh Phaiju

description of our project

quick it is the uber for delivery and motto of our product is for the people and to the people. we are providig the platform for those people who are in need of urgent delivery and those who want to earn money by providing services.
Our implementation plan will held into four different sprint.
sprit 1: normal statics pages.
sprint 2. testing and implement on server.
sprint 3. building server and add function.
sprint 4. testing and complete assignment.


here is django documentation.
https://docs.djangoproject.com/en/2.0/

sprint 1 plan:
finishing all plan.
starting implementation: login page, static pages like user can log in sign in , see payment function (probably fake), we might use geogle tracking system just to find users.

