from django.apps import AppConfig


class FormpageConfig(AppConfig):
    name = 'formpage'
