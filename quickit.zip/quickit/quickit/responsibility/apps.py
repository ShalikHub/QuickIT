from django.apps import AppConfig


class ResponsibilityConfig(AppConfig):
    name = 'responsibility'
