from django.contrib import admin
from responsibility.models import Responsibility

admin.site.register(Responsibility)

# Register your models here.
